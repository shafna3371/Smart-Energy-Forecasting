from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='login'),
    path('home/', views.home_view, name='home'),
    path('logout/', views.logout_view, name='logout'),
    path('toggle/<int:device_id>/', views.toggle_device, name='toggle_device'),

    # NEW API
    path('live-data/', views.get_live_data, name='live_data'),
]
