const ctx = document.getElementById('usageChart').getContext('2d');
let totalUsage = 0;

// Initialize Chart
const usageChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: [],
        datasets: [{
            label: 'Usage (kW)',
            data: [],
            borderColor: '#3b82f6',
            tension: 0.4,
            fill: true,
            backgroundColor: 'rgba(59, 130, 246, 0.1)'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: { beginAtZero: true, grid: { color: '#334155' } },
            x: { grid: { display: false } }
        }
    }
});

// Simulate Real-Time Data
function updateData() {
    const now = new Date();
    const timeLabel = now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
    
    // Generate random consumption between 0.5kW and 4.0kW
    const currentKW = (Math.random() * (4.0 - 0.5) + 0.5).toFixed(2);
    
    // Update UI Cards
    document.getElementById('current-usage').innerText = `${currentKW} kW`;
    
    totalUsage += parseFloat(currentKW) / 1800; // Simplified hourly conversion
    document.getElementById('daily-total').innerText = `${totalUsage.toFixed(2)} kWh`;
    document.getElementById('cost').innerText = `$${(totalUsage * 0.15).toFixed(2)}`;

    // Update Chart
    if (usageChart.data.labels.length > 10) {
        usageChart.data.labels.shift();
        usageChart.data.datasets[0].data.shift();
    }
    
    usageChart.data.labels.push(timeLabel);
    usageChart.data.datasets[0].data.push(currentKW);
    usageChart.update();
}

// Update every 2 seconds
setInterval(updateData, 2000);