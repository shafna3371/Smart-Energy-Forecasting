from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from .models import Device


def login_view(request):
    # Always show login page first
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            error = "Invalid username or password"
            return render(request, 'login.html', {'error': error})

    return render(request, 'login.html')



@login_required(login_url='login')
def home_view(request):
    devices = Device.objects.filter(user=request.user)

    total_load = 0
    stealth = 0

    for d in devices:
        if d.is_on:
            total_load += d.power
        else:
            stealth += d.standby_power

    total_load += stealth

    rate = 35
    cost = (total_load / 1000) * rate

    if total_load < 500:
        score = 100
    elif total_load < 1500:
        score = 80
    else:
        score = 60

    context = {
        'devices': devices,
        'total_load': round(total_load, 2),
        'cost': round(cost, 2),
        'stealth': round(stealth, 2),
        'score': score,
    }

    return render(request, 'home.html', context)


@login_required
def get_live_data(request):
    devices = Device.objects.filter(user=request.user)

    total_load = 0
    stealth = 0

    for d in devices:
        if d.is_on:
            total_load += d.power
        else:
            stealth += d.standby_power

    total_load += stealth

    rate = 35
    cost = (total_load / 1000) * rate

    if total_load < 500:
        score = 100
    elif total_load < 1500:
        score = 80
    else:
        score = 60

    return JsonResponse({
        "load": round(total_load, 2),
        "cost": round(cost, 2),
        "stealth": round(stealth, 2),
        "score": score
    })


@login_required(login_url='login')
def logout_view(request):
    logout(request)
    return redirect('login')


@login_required
def toggle_device(request, device_id):
    device = Device.objects.get(id=device_id, user=request.user)
    device.is_on = not device.is_on
    device.save()
    return redirect('home')
