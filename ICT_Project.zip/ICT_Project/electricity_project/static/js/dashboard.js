const ctx = document.getElementById('liveChart').getContext('2d');

let dataPoints = Array(30).fill(0);

let currentLoad = 0;
let targetLoad = 0;
let currentMaxY = 50;

const gradient = ctx.createLinearGradient(0, 0, 0, 400);
gradient.addColorStop(0, 'rgba(45, 212, 191, 0.3)');
gradient.addColorStop(1, 'rgba(45, 212, 191, 0)');

const liveChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: Array(30).fill(''),
        datasets: [{
            data: dataPoints,
            borderColor: '#2dd4bf',
            borderWidth: 3,
            fill: true,
            backgroundColor: gradient,
            tension: 0.4,
            pointRadius: 0
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: false,
        plugins: { legend: { display: false } },
        scales: {
            x: { display: false },
            y: {
                min: 0,
                max: currentMaxY,
                grid: { color: '#1e293b' },
                ticks: { color: '#64748b' }
            }
        }
    }
});


// Update dashboard values
function updateDashboardValues(data) {
    document.getElementById("loadValue").innerText = data.load;
    document.getElementById("costValue").innerText = data.cost;
    document.getElementById("stealthValue").innerText = data.stealth;
    document.getElementById("scoreValue").innerText = data.score;

    targetLoad = data.load;
}


// Smooth engine
setInterval(() => {

    // Smooth transition toward target
    currentLoad += (targetLoad - currentLoad) * 0.08;

    let displayValue;
    let desiredMax;

    // ===== CASE 1: All devices OFF =====
    if (targetLoad < 5) {

        // Keep near zero
        displayValue = Math.random() * 1.5;

        // Lock Y-axis small (no growth)
        desiredMax = 50;
    }

    // ===== CASE 2: Devices ON =====
    else {
        let noise = currentLoad * (Math.random() * 0.05 - 0.025);
        displayValue = currentLoad + noise;

        desiredMax = targetLoad * 1.5;
    }

    // Smooth Y-axis change
    currentMaxY += (desiredMax - currentMaxY) * 0.1;
    liveChart.options.scales.y.max = currentMaxY;

    // Update graph
    liveChart.data.datasets[0].data.shift();
    liveChart.data.datasets[0].data.push(displayValue);
    liveChart.update('none');

}, 200);


// Fetch backend data every second
setInterval(() => {
    fetch('/live-data/')
        .then(response => response.json())
        .then(data => {
            updateDashboardValues(data);
        });
}, 1000);
